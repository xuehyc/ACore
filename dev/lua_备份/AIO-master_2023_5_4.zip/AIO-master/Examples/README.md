This folder contains example files for how to use AIO. Each folder or file in this folder is an example of it's own.

To run the examples place all of their files to `/lua_scripts/` folder on your server. No files are placed on the client side folders.
The files that have `client` in their name are usually sent in their entirety to the client from the server.
Many examples have a lot of comments and it is recommended to try read through the comments to understand how the examples work.
